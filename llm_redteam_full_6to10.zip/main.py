
from fastapi import FastAPI
from routers.ai_router import router as ai_router
from routers.review import router as review_router
from utils.rate_limiter import rate_limit_middleware
from services.review_queue import init_db
import uvicorn

app = FastAPI(title="AI Cyber Threat Detection Backend", version="1.0.0")

# init DB (sqlite) for review queue
init_db()

# Register middleware
app.middleware("http")(rate_limit_middleware)

# include routers
app.include_router(ai_router)
app.include_router(review_router)

@app.get("/")
async def root():
    return {"message": "AI Cyber Threat Detection Backend is running!"}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
